from typing import Union
from sqlalchemy.engine.base import Engine

def create_schema_manager(storage_type="file", **kwargs):
    """
    Create a schema manager based on the specified storage type.
    
    Args:
        storage_type: "file" or "database"
        **kwargs: Additional arguments for the specific manager type
            For "file":
                filename (str): Name of the schema storage file. Defaults to "schemas.barfi".
                filepath (str): Directory path for schema storage. Defaults to "./".
            For "database":
                engine: SQLAlchemy engine or connection string (required)
                schema_table (str): Table name for storing schemas. Defaults to "barfi_schemas".
    
    Returns:
        A schema manager instance (SchemaManager or SQLAlchemySchemaManager)
        
    Raises:
        ValueError: If storage_type is unknown or required arguments are missing
    """
    if storage_type == "file":
        from barfi.flow.schema.manage import SchemaManager
        filename = kwargs.get("filename", "schemas.barfi")
        filepath = kwargs.get("filepath", "./")
        return SchemaManager(filename=filename, filepath=filepath)
    
    elif storage_type == "database":
        from barfi.flow.schema.sql_manage import SQLAlchemySchemaManager
        engine = kwargs.get("engine")
        if engine is None:
            raise ValueError("SQLAlchemy engine or connection string is required for database storage")
        
        schema_table = kwargs.get("schema_table", "barfi_schemas")
        return SQLAlchemySchemaManager(
            engine_or_connection_string=engine,
            schema_table=schema_table
        )
    
    else:
        raise ValueError(f"Unknown storage type: {storage_type}") 