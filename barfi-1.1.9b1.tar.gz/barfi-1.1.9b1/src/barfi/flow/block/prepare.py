from typing import Union, List, Dict, Any
from barfi.flow.block import Block


def prepare_blocks_export(
    base_blocks: Union[Block, List[Block], Dict[str, Union[Block, List[Block]]]],
):
    # Handle case where a single Block is passed
    if isinstance(base_blocks, Block):
        base_blocks = [base_blocks]
        
    if isinstance(base_blocks, list):
        names = [block.name for block in base_blocks]
        duplicate_names = {name for name in names if names.count(name) > 1}
        if duplicate_names:
            raise ValueError(f"Duplicate blocks found: {duplicate_names}")

        base_blocks_data = [block._export() for block in base_blocks]
    elif isinstance(base_blocks, dict):
        processed_dict = {}
        
        for category, blocks in base_blocks.items():
            # Convert single Block to list for consistent processing
            if isinstance(blocks, Block):
                blocks = [blocks]
                processed_dict[category] = blocks
            else:
                processed_dict[category] = blocks
                
            names = [block.name for block in blocks]
            duplicate_names = {name for name in names if names.count(name) > 1}
            if duplicate_names:
                raise ValueError(
                    f"Duplicate blocks found in category '{category}': {duplicate_names}"
                )

        base_blocks_data = {
            category: [block._export() for block in blocks]
            for category, blocks in processed_dict.items()
        }
    else:
        raise ValueError("base_blocks must be a Block, a list of blocks, or a dict of blocks.")

    return base_blocks_data
