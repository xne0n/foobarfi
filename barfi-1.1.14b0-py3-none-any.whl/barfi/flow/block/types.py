from dataclasses import dataclass
from typing import Optional

@dataclass
class JsonParameter:
    field: str
    description: str
    type: str
    options: Optional[str] = None
    value: Optional[str] = None 