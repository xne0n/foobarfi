import json
from typing import Dict, List
from sqlalchemy import Table, Column, Integer, Text, MetaData, create_engine
from sqlalchemy import select, insert, update, delete
from barfi.flow.schema.types import FlowSchema, build_flow_schema_from_dict


class SQLAlchemySchemaManager:
    """Manages schema operations for loading, saving, and deleting schemas using an SQLAlchemy database.
    
    Handles schema persistence using an SQL database with a simple schema:
    - schema_id (primary key): The name of the schema
    - schema_data: The JSON representation of the schema
    """
    
    def __init__(self, engine_or_connection_string, schema_table="barfi_schemas"):
        """Initialize SQLAlchemySchemaManager with database configuration.
        
        Args:
            engine_or_connection_string: SQLAlchemy engine or connection string
            schema_table: Name of the table to store schemas. Defaults to "barfi_schemas".
        """
        # Set up SQLAlchemy engine
        if isinstance(engine_or_connection_string, str):
            self.engine = create_engine(engine_or_connection_string)
        else:
            self.engine = engine_or_connection_string
            
        self.schema_table = schema_table
        
        # We don't load all schemas into memory, only their names
        self._schema_ids = self._get_schema_ids()
        
    def _get_schema_ids(self) -> List[int]:
        """Get the list of schema names from the database."""
        metadata = MetaData()
        schema_table = Table(self.schema_table, metadata, autoload_with=self.engine)
        
        with self.engine.connect() as conn:
            result = conn.execute(select(schema_table.c.schema_id))
            return [row[0] for row in result]
    
    @property
    def schema_ids(self) -> List[int]:
        """Get the list of available schema names."""
        # Refresh the schema names to ensure we have the latest
        self._schema_ids = self._get_schema_ids()
        return self._schema_ids
    
    def save_schema(self, flow_schema: FlowSchema):
        """Store a schema with the given name and return the generated schema_id.

        Args:
            flow_schema (FlowSchema): Schema configuration to store

        Returns:
            int: The auto-generated schema_id of the newly inserted schema
        """
        metadata = MetaData()
        schema_table = Table(self.schema_table, metadata, autoload_with=self.engine)

        # Convert the schema to JSON
        schema_data = json.dumps(flow_schema.export())

        with self.engine.begin() as conn:
            result = conn.execute(
                insert(schema_table).values(
                    schema_data=schema_data
                ).returning(schema_table.c.schema_id)
            )

            # Fetch the generated schema_id
            generated_schema_id = result.scalar()

        # Update local schema names
        self._schema_ids = self._get_schema_ids()

        return int(generated_schema_id)
    
    def update_schema(self, schema_id: int, flow_schema: FlowSchema):
        """Update an existing schema with new configuration.
        
        Args:
            schema_id (str): Identifier of the schema to update
            flow_schema (FlowSchema): New schema configuration
            
        Raises:
            ValueError: When schema_id doesn't exist in database
        """
        if schema_id not in self.schema_ids:
            raise ValueError(
                f"FlowSchema `{schema_id}` not found. Use save_schema() to create new schemas."
            )
            
        metadata = MetaData()
        schema_table = Table(self.schema_table, metadata, autoload_with=self.engine)
        
        # Convert the schema to JSON
        schema_data = json.dumps(flow_schema.export())
        
        with self.engine.begin() as conn:
            conn.execute(
                update(schema_table)
                .where(schema_table.c.schema_id == schema_id)
                .values(schema_data=schema_data)
            )
    
    def upsert_schema(self, schema_id: int, flow_schema: FlowSchema):
        """Create or update a schema with new configuration.
        
        Args:
            schema_id (str): Identifier of the schema
            flow_schema (FlowSchema): New schema configuration
        """
        if schema_id in self.schema_ids:
            self.update_schema(schema_id, flow_schema)
            return schema_id
        else:
            return self.save_schema(flow_schema)
    
    def load_schema(self, schema_id: int) -> FlowSchema:
        """Retrieve a schema by its name.
        
        Args:
            schema_id (str): Identifier of the schema to load
            
        Returns:
            FlowSchema: The loaded schema configuration
            
        Raises:
            ValueError: When schema_id doesn't exist in database
        """
        if schema_id not in self.schema_ids:
            raise ValueError(f"FlowSchema `{schema_id}` not found in the saved schemas")
            
        metadata = MetaData()
        schema_table = Table(self.schema_table, metadata, autoload_with=self.engine)
        
        with self.engine.connect() as conn:
            result = conn.execute(
                select(schema_table.c.schema_data)
                .where(schema_table.c.schema_id == schema_id)
            )
            row = result.fetchone()
            
            if row:
                schema_data = json.loads(row[0])
                return build_flow_schema_from_dict(schema_data)
            else:
                # This should never happen because we checked schema_id earlier
                raise ValueError(f"FlowSchema `{schema_id}` not found in the database")
    
    def delete_schema(self, schema_id: str):
        """Remove a schema from the database.
        
        Args:
            schema_id (str): Identifier of the schema to delete
            
        Raises:
            ValueError: When schema_id doesn't exist in database
        """
        if schema_id not in self.schema_ids:
            raise ValueError(f"FlowSchema `{schema_id}` not found in the saved schemas")
            
        metadata = MetaData()
        schema_table = Table(self.schema_table, metadata, autoload_with=self.engine)
        
        with self.engine.begin() as conn:
            conn.execute(
                delete(schema_table)
                .where(schema_table.c.schema_id == schema_id)
            )
            
        # Update local schema names
        self._schema_ids = self._get_schema_ids() 