from typing import Union, List, Optional, Dict, Any
from dataclasses import dataclass, field

BlockOptionValue = Union[int, float, str, None, bool, Dict[str, List[str]]]


@dataclass
class BlockOption:
    name: str
    type: str
    value: Optional[BlockOptionValue] = None
    min: Optional[Union[int, float]] = None
    max: Optional[Union[int, float]] = None
    items: List[str] = field(default_factory=list)
    properties: dict = field(default_factory=dict)
    hint: Optional[str] = None
    dictionary: Optional[Dict[str, Any]] = None

    @classmethod
    def build(cls, name: str, type: str, kwargs):
        # Extract hint from kwargs if present
        hint = kwargs.get("hint")
        
        if type == "checkbox":
            value = kwargs.get("value", False)
            assert isinstance(
                value, bool
            ), "Error: For checkbox option, 'value' must be of type boolean."
            return cls(name=name, type="CheckboxOption", value=value, hint=hint)

        elif type == "input":
            value = kwargs.get("value", "Text input")
            assert isinstance(
                value, str
            ), "Error: For input option, 'value' must be of type string."
            return cls(name=name, type="InputOption", value=value, hint=hint)

        elif type == "textarea":
            value = kwargs.get("value", "TextArea input")
            assert isinstance(
                value, str
            ), "Error: For textarea option, 'value' must be of type string."
            return cls(name=name, type="TextAreaOption", value=value, hint=hint)

        elif type == "pythoneditor":
            value = kwargs.get("value", "Start coding here")
            assert isinstance(
                value, str
            ), "Error: For pythoneditor option, 'value' must be of type string."
            return cls(name=name, type="PythonEditorOption", value=value, hint=hint)

        elif type == "integer":
            value = kwargs.get("value")
            min_val = kwargs.get("min")
            max_val = kwargs.get("max")
            assert value is None or isinstance(
                value, int
            ), "Error: For integer option, 'value' must be of type integer."
            assert min_val is None or isinstance(
                min_val, int
            ), "Error: For integer option, 'min' must be of type integer."
            assert max_val is None or isinstance(
                max_val, int
            ), "Error: For integer option, 'max' must be of type integer."
            return cls(
                name=name,
                type="IntegerOption",
                value=value,
                min=min_val,
                max=max_val,
                properties={"min": min_val, "max": max_val},
                hint=hint
            )

        elif type == "number":
            value = kwargs.get("value")
            min_val = kwargs.get("min")
            max_val = kwargs.get("max")
            assert value is None or isinstance(
                value, (int, float)
            ), "Error: For number option, 'value' must be of type integer or float."
            assert min_val is None or isinstance(
                min_val, (int, float)
            ), "Error: For number option, 'min' must be of type integer or float."
            assert max_val is None or isinstance(
                max_val, (int, float)
            ), "Error: For number option, 'max' must be of type integer or float."
            return cls(
                name=name,
                type="NumberOption",
                value=value,
                min=min_val,
                max=max_val,
                properties={"min": min_val, "max": max_val},
                hint=hint
            )

        elif type == "select":
            value = kwargs.get("value")
            items = kwargs.get("items", [])
            assert bool(
                items
            ), "Error: There are no items specified for the select option."
            assert all(
                isinstance(item, str) for item in items
            ), "Error: items specified for the select option must all be of type string."
            if value is not None:
                assert isinstance(
                    value, str
                ), "Error: For select option, 'value' must be of type string."
                assert (
                    value in items
                ), "Error: The selected value must be one of the items."
            return cls(
                name=name,
                type="SelectOption",
                value=value,
                items=items,
                properties={"items": items},
                hint=hint
            )

        elif type == "multiselect":
            value = kwargs.get("value", [])
            items = kwargs.get("items", [])
            assert bool(
                items
            ), "Error: There are no items specified for the select option."
            assert all(
                isinstance(item, str) for item in items
            ), "Error: items specified for the select option must all be of type string."
            if value is not None:
                assert isinstance(
                    value, list
                ), "Error: For multiselect option, 'value' must be of type list."
                assert (
                    all(v in items for v in value) or len(value) == 0
                ), "Error: Every item in value must be in items."
            return cls(
                name=name,
                type="MultiSelectOption",
                value=value if value is not None else [],
                items=items,
                properties={"items": items},
                hint=hint
            )

        elif type == "slider":
            value = kwargs.get("value")
            min_val = kwargs.get("min")
            max_val = kwargs.get("max")
            assert (
                min_val is not None
            ), "Error: For slider option, 'min' must be specified."
            assert (
                max_val is not None
            ), "Error: For slider option, 'max' must be specified."
            assert isinstance(
                min_val, (int, float)
            ), "Error: For slider option, 'min' must be of type float or integer."
            assert isinstance(
                max_val, (int, float)
            ), "Error: For slider option, 'max' must be of type float or integer."
            if value is not None:
                assert isinstance(
                    value, (int, float)
                ), "Error: For slider option, 'value' must be of type float or integer."
                assert (
                    min_val <= value <= max_val
                ), "Error: For slider option, 'value' must be between 'min' and 'max'."
            return cls(
                name=name,
                type="SliderOption",
                value=value,
                min=min_val,
                max=max_val,
                properties={"min": min_val, "max": max_val},
                hint=hint
            )

        elif type == "display":
            value = kwargs.get("value", None)
            assert isinstance(
                value, str
            ), "Error: For display option, 'value' must be of type string."
            return cls(name=name, type="DisplayOption", value=value, hint=hint)

        elif type == "filterselect":
            value = kwargs.get("value", {})
            dictionary = kwargs.get("dictionary", {})
            assert isinstance(
                value, dict
            ), "Error: For filterselect option, 'value' must be of type dict."
            assert isinstance(
                dictionary, dict
            ), "Error: For filterselect option, 'dictionary' must be of type dict."
            return cls(
                name=name, 
                type="FilterSelectOption", 
                value=value, 
                dictionary=dictionary,
                properties={"dictionary": dictionary},
                hint=hint
            )

        else:
            raise ValueError(
                "Error: No valid option type passed to the add_option method."
            )
