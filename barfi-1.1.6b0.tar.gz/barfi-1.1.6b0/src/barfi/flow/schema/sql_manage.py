import json
from typing import Dict, List
from sqlalchemy import Table, Column, String, Text, MetaData, create_engine
from sqlalchemy import select, insert, update, delete
from barfi.flow.schema.types import FlowSchema, build_flow_schema_from_dict


class SQLAlchemySchemaManager:
    """Manages schema operations for loading, saving, and deleting schemas using an SQLAlchemy database.
    
    Handles schema persistence using an SQL database with a simple schema:
    - schema_name (primary key): The name of the schema
    - schema_data: The JSON representation of the schema
    """
    
    def __init__(self, engine_or_connection_string, schema_table="barfi_schemas"):
        """Initialize SQLAlchemySchemaManager with database configuration.
        
        Args:
            engine_or_connection_string: SQLAlchemy engine or connection string
            schema_table: Name of the table to store schemas. Defaults to "barfi_schemas".
        """
        # Set up SQLAlchemy engine
        if isinstance(engine_or_connection_string, str):
            self.engine = create_engine(engine_or_connection_string)
        else:
            self.engine = engine_or_connection_string
            
        self.schema_table = schema_table
        self._ensure_table_exists()
        
        # We don't load all schemas into memory, only their names
        self._schema_names = self._get_schema_names()
    
    def _ensure_table_exists(self):
        """Create the schema table if it doesn't exist."""
        metadata = MetaData()
        Table(
            self.schema_table,
            metadata,
            Column('schema_name', String(255), primary_key=True),
            Column('schema_data', Text, nullable=False),
            extend_existing=True
        )
        
        metadata.create_all(self.engine)
    
    def _get_schema_names(self) -> List[str]:
        """Get the list of schema names from the database."""
        metadata = MetaData()
        schema_table = Table(self.schema_table, metadata, autoload_with=self.engine)
        
        with self.engine.connect() as conn:
            result = conn.execute(select(schema_table.c.schema_name))
            return [row[0] for row in result]
    
    @property
    def schema_names(self) -> List[str]:
        """Get the list of available schema names."""
        # Refresh the schema names to ensure we have the latest
        self._schema_names = self._get_schema_names()
        return self._schema_names
    
    def save_schema(self, schema_name: str, flow_schema: FlowSchema):
        """Store a schema with the given name.
        
        Args:
            schema_name (str): Unique identifier for the schema
            flow_schema (FlowSchema): Schema configuration to store
            
        Raises:
            ValueError: When schema_name already exists in database
        """
        if schema_name in self.schema_names:
            raise ValueError(
                f"FlowSchema `{schema_name}` already exists. Use update_schema() to modify existing schemas."
            )
            
        metadata = MetaData()
        schema_table = Table(self.schema_table, metadata, autoload_with=self.engine)
        
        # Convert the schema to JSON
        schema_data = json.dumps(flow_schema.export())
        
        with self.engine.begin() as conn:
            conn.execute(
                insert(schema_table).values(
                    schema_name=schema_name,
                    schema_data=schema_data
                )
            )
            
        # Update local schema names
        self._schema_names = self._get_schema_names()
    
    def update_schema(self, schema_name: str, flow_schema: FlowSchema):
        """Update an existing schema with new configuration.
        
        Args:
            schema_name (str): Identifier of the schema to update
            flow_schema (FlowSchema): New schema configuration
            
        Raises:
            ValueError: When schema_name doesn't exist in database
        """
        if schema_name not in self.schema_names:
            raise ValueError(
                f"FlowSchema `{schema_name}` not found. Use save_schema() to create new schemas."
            )
            
        metadata = MetaData()
        schema_table = Table(self.schema_table, metadata, autoload_with=self.engine)
        
        # Convert the schema to JSON
        schema_data = json.dumps(flow_schema.export())
        
        with self.engine.begin() as conn:
            conn.execute(
                update(schema_table)
                .where(schema_table.c.schema_name == schema_name)
                .values(schema_data=schema_data)
            )
    
    def upsert_schema(self, schema_name: str, flow_schema: FlowSchema):
        """Create or update a schema with new configuration.
        
        Args:
            schema_name (str): Identifier of the schema
            flow_schema (FlowSchema): New schema configuration
        """
        if schema_name in self.schema_names:
            self.update_schema(schema_name, flow_schema)
        else:
            self.save_schema(schema_name, flow_schema)
    
    def load_schema(self, schema_name: str) -> FlowSchema:
        """Retrieve a schema by its name.
        
        Args:
            schema_name (str): Identifier of the schema to load
            
        Returns:
            FlowSchema: The loaded schema configuration
            
        Raises:
            ValueError: When schema_name doesn't exist in database
        """
        if schema_name not in self.schema_names:
            raise ValueError(f"FlowSchema `{schema_name}` not found in the saved schemas")
            
        metadata = MetaData()
        schema_table = Table(self.schema_table, metadata, autoload_with=self.engine)
        
        with self.engine.connect() as conn:
            result = conn.execute(
                select(schema_table.c.schema_data)
                .where(schema_table.c.schema_name == schema_name)
            )
            row = result.fetchone()
            
            if row:
                schema_data = json.loads(row[0])
                return build_flow_schema_from_dict(schema_data)
            else:
                # This should never happen because we checked schema_name earlier
                raise ValueError(f"FlowSchema `{schema_name}` not found in the database")
    
    def delete_schema(self, schema_name: str):
        """Remove a schema from the database.
        
        Args:
            schema_name (str): Identifier of the schema to delete
            
        Raises:
            ValueError: When schema_name doesn't exist in database
        """
        if schema_name not in self.schema_names:
            raise ValueError(f"FlowSchema `{schema_name}` not found in the saved schemas")
            
        metadata = MetaData()
        schema_table = Table(self.schema_table, metadata, autoload_with=self.engine)
        
        with self.engine.begin() as conn:
            conn.execute(
                delete(schema_table)
                .where(schema_table.c.schema_name == schema_name)
            )
            
        # Update local schema names
        self._schema_names = self._get_schema_names() 