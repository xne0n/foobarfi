import uuid
import inspect
import json
from types import MethodType
from typing import Callable, Any, Dict, List, Type, Optional, Literal, Union
from dataclasses import asdict, dataclass, field
from barfi.flow.block.option import BlockOption, BlockOptionValue
from barfi.flow.block.interface import BlockInterface, IT, is_valid_interface_type

@dataclass
class Block:
    # Public fields
    name: str = "Block"
    # Type of block to use for display in the UI
    block_display_type: Literal["baseBlock", "customBlock", "descBlock"] = "baseBlock"
    header_color: Optional[str] = None

    # Private fields (excluded from init and compare)
    _type: str = field(init=False, repr=False, compare=False)
    _inputs: Dict[str, BlockInterface] = field(init=False, default_factory=dict, compare=False)
    _outputs: Dict[str, BlockInterface] = field(init=False, default_factory=dict, compare=False)
    _options: Dict[str, BlockOption] = field(init=False, default_factory=dict, compare=False)
    _state: Dict[str, object] = field(init=False, default_factory=lambda: {"info": None}, repr=False, compare=False)
    _interface_names: List[str] = field(init=False, default_factory=list, repr=False, compare=False)
    # Dedicated field for the bloc-description option.
    block_description: Optional[BlockOption] = field(init=False, default=None, compare=False, repr=False)

    def __post_init__(self):
        """
        Post-initialization to set up private fields based on the given `name`.
        """
        if self.name == "Block":
            self.name = f"Block_{str(uuid.uuid4()).replace('-', '_')}"
        self._type = self.name

    def add_input(self, name: str = None, interface_type: Type[IT] = Any) -> "Block":
        """
        Add an Input interface to the Block.
        """
        is_valid_interface_type(interface_type)
        if name is None:
            name = f"Input {len(self._inputs) + 1}"
        if name in self._interface_names:
            raise ValueError(f"name: {name} already exists as an interface to the Block.")
        self._inputs[name] = BlockInterface[interface_type](name=name)
        self._interface_names.append(name)
        return self

    def add_output(self, name: str = None, interface_type: Type[IT] = Any) -> "Block":
        """
        Add an Output interface to the Block.
        """
        is_valid_interface_type(interface_type)
        if name is None:
            name = f"Output {len(self._outputs) + 1}"
        if name in self._interface_names:
            raise ValueError(f"name: {name} already exists as an interface to the Block.")
        self._outputs[name] = BlockInterface[interface_type](name=name)
        self._interface_names.append(name)
        return self

    def get_interface(self, name: str):
        """
        Get the value of a given interface.
        """
        if name in self._inputs:
            return self._inputs[name].value
        elif name in self._outputs:
            return self._outputs[name].value
        else:
            raise ValueError(f"No interface with name: {name} found for Block")

    def set_interface(self, name: str, value) -> "Block":
        """
        Set the value for a given interface.
        """
        if name in self._inputs:
            self._inputs[name].set_value(value)
        elif name in self._outputs:
            self._outputs[name].set_value(value)
        else:
            raise ValueError(f"No interface with name: {name} found for Block")
        return self

    def set_state(self, key: str, value: Any) -> "Block":
        """
        Set a state value for the block.
        Reserved keys: ['info']
        """
        reserved_state_keys = ["info"]
        if key in reserved_state_keys:
            raise ValueError(f"Key: {key} used for setting state of block is reserved. Use another key.")
        else:
            self._state[key] = value
        return self

    def get_state(self, key: str) -> Any:
        """
        Get a state value for the block.
        """
        if key in self._state:
            return self._state[key]
        else:
            raise ValueError(f"Key: {key} does not exist in state.")

    def add_option(self, name: str, type: str, **kwargs) -> "Block":
        """
        Add an interactive Option interface to the Block.
        Note: Use add_description() to add a bloc-description.
        """
        if name == "bloc-description":
            raise ValueError("Use add_description() to add a bloc-description instead of add_option().")
        assert isinstance(name, str), "Error: 'name' argument should be of type string."
        assert isinstance(type, str), "Error: 'type' argument should be of type string."
        assert type in [
            "checkbox", "input", "integer", "number", "select", "multiselect",
            "slider", "display", "textarea", "pythoneditor",
        ], 'Error: Option "type" is not a standard Option interface parameter.'
        if name in self._options:
            raise ValueError(f"Option with name: {name} already exists in Block.")
        option = BlockOption.build(name, type, kwargs)
        self._options[name] = option
        return self

    def add_description(self, **kwargs) -> "Block":
        """
        Add a dedicated bloc-description option to the Block.
        This creates a TextAreaOption with the fixed name "bloc-description".
        Optionally, you can override properties via kwargs.
        """
        if self.block_description is not None:
            raise ValueError("bloc-description has already been added to this Block.")
        option = BlockOption.build("bloc-description", "textarea", kwargs)
        self.block_description = option
        self._options["bloc-description"] = option
        return self

    def set_option(self, name: str, **kwargs) -> "Block":
        """
        Set the value of an existing Option interface in the Block.
        """
        if name == "bloc-description":
            if self.block_description is None:
                raise ValueError("bloc-description option has not been added to Block.")
            for arg, value in kwargs.items():
                if arg in self.block_description.__dict__:
                    # Allow setting value and hint properties
                    if arg in ["value", "hint"]:
                        setattr(self.block_description, arg, value)
                    else:
                        raise ValueError(f"Cannot set or invalid property: {arg} for bloc-description.")
                else:
                    raise ValueError(f"Property: {arg} is not a valid option property for bloc-description.")
        elif name in self._options:
            for arg, value in kwargs.items():
                if arg in self._options[name].__dict__:
                    # Allow setting value and hint properties
                    if arg in ["value", "hint"]:
                        setattr(self._options[name], arg, value)
                    else:
                        raise ValueError(f"Cannot set or invalid property: {arg} for Block option.")
                else:
                    raise ValueError(f"Property: {arg} is not a valid option property for {name}.")
        else:
            raise ValueError(f"Option name: {name} does not exist in Block.")
        return self

    def get_option(self, name: str) -> BlockOptionValue:
        """
        Get the value of an existing Option interface in the Block.
        """
        if name == "bloc-description":
            if self.block_description is None:
                raise ValueError("bloc-description option does not exist in Block.")
            return self.block_description.value
        elif name in self._options:
            return self._options[name].value
        else:
            raise ValueError(f"Option name: {name} does not exist in Block.")

    def _export(self) -> dict:
        """
        Export the block's data as a dictionary.
        """
        export_data = {
            "name": self.name,
            "type": self._type,
            "block_display_type": self.block_display_type,
            "inputs": [inp.export() for inp in self._inputs.values()],
            "outputs": [out.export() for out in self._outputs.values()],
            "options": [asdict(option) for option in self._options.values()],
            "headerColor": self.header_color,  # Include header color in export
        }
        
        # For descBlock, use the block_description value in the description field
        if self.block_display_type == "descBlock":
            description_value = ""
            if self.block_description is not None:
                description_value = self.block_description.value
            export_data["description"] = description_value
        # For other block types with a blockDescription, include it separately
        elif self.block_description is not None:
            export_data["blockDescription"] = asdict(self.block_description)
        
        return export_data

    async def _on_compute(self) -> None:
        """
        Default compute method for the block.
        This method is meant to be overridden by the user-defined compute function.
        Can be either synchronous or asynchronous.
        """
        pass

    def add_compute(self, _func: Callable[["Block"], Any]) -> "Block":
        """
        Add a compute function to the block.
        """
        if inspect.iscoroutinefunction(_func):
            self._on_compute = MethodType(_func, self)
        else:
            async def wrapper(self):
                return _func(self)
            self._on_compute = MethodType(wrapper, self)
        return self

    @classmethod
    def from_dict(cls, data: dict) -> "Block":
        """
        Create a Block instance from a dictionary (e.g., loaded from JSON).
        """
        # Validate display type
        block_display_type = data.get("block_display_type", "baseBlock")
        if block_display_type not in ["baseBlock", "customBlock", "descBlock"]:
            block_display_type = "baseBlock"  # Default to baseBlock for invalid values
            
        block = cls(
            name=data.get("name", "Block"),
            block_display_type=block_display_type
        )
        # Reconstruct inputs if provided
        for inp in data.get("inputs", []):
            block.add_input(name=inp.get("name"), interface_type=inp.get("interface_type", Any))
        # Reconstruct outputs if provided
        for out in data.get("outputs", []):
            block.add_output(name=out.get("name"), interface_type=out.get("interface_type", Any))
        # Reconstruct options (including the dedicated description)
        for opt in data.get("options", []):
            if opt.get("name") == "bloc-description":
                block.add_description(**opt)
            else:
                kwargs = {k: v for k, v in opt.items() if k not in ("name", "type")}
                block.add_option(name=opt["name"], type=opt["type"], **kwargs)
        
        # For descBlock, ensure we have description or create it from blockDescription
        if block_display_type == "descBlock" and "description" not in data:
            if "code" not in block._options:
                # Add code option for descBlock if needed
                block.add_option(name="description", type="textarea", value="")
        
        return block

    @classmethod
    def from_json(cls, json_str: str) -> "Block":
        """
        Create a Block instance from a JSON string.
        """
        data = json.loads(json_str)
        return cls.from_dict(data)
