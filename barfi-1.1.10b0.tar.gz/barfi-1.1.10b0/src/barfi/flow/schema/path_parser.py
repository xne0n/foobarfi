"""
Flow schema parsing utility for identifying single paths in flow diagrams.

This module provides functions to parse Barfi flow schemas into human-readable
text representations focused on single paths.
"""

import sys
from typing import Dict, List, Any, Set, Tuple, Optional
import json
from barfi.flow.schema.types import FlowSchema


def parse_single_path_from_lowest_x(flow_schema: FlowSchema) -> str:
    """
    Parses the process flow schema to find a single path based on the
    lowest X-coordinate node, tracing backwards to find its root,
    and then forwards until a branch or merge point.

    Args:
        flow_schema (FlowSchema): A FlowSchema object containing the process flow data.

    Returns:
        str: A formatted string describing the single identified process path.
    """
    nodes = flow_schema.nodes
    connections = flow_schema.connections

    if not nodes:
        return "Error: No nodes found in the flow schema."

    # --- 1. Preprocessing ---
    nodes_dict = {}
    min_x = sys.float_info.max
    lowest_x_node_id = None

    for node in nodes:
        node_id = node.id
        if not node_id:
            print(f"Warning: Found node without ID: {node.label}")
            continue
        nodes_dict[node_id] = node
        try:
            pos_x = float(node.position.x)
            if pos_x < min_x:
                min_x = pos_x
                lowest_x_node_id = node_id
        except (ValueError, TypeError):
             print(f"Warning: Could not parse X position for node {node_id}. Skipping for lowest X check.")

    if lowest_x_node_id is None:
        return "Error: Could not determine the node with the lowest X coordinate (check position data)."

    # Build incoming/outgoing connection lookups
    # outgoing: {'node_id': [{'to_node': id, 'from_interface': name}, ...]}
    outgoing_connections = {node_id: [] for node_id in nodes_dict}
    # incoming: {'node_id': [{'from_node': id, 'to_interface': name}, ...]}
    incoming_connections = {node_id: [] for node_id in nodes_dict}

    for conn in connections:
        output_node = conn.outputNode
        input_node = conn.inputNode
        output_interface = conn.outputNodeInterface
        input_interface = conn.inputNodeInterface

        if output_node and input_node and output_interface and output_node in nodes_dict:
            outgoing_connections[output_node].append({
                'to_node': input_node,
                'from_interface': output_interface
            })

        if input_node and output_node and input_interface and input_node in nodes_dict:
             incoming_connections[input_node].append({
                'from_node': output_node,
                'to_interface': input_interface
            })

    output_lines = []
    output_lines.append("--- Path Identification ---")
    output_lines.append(f"Node with lowest X coordinate: {lowest_x_node_id} (X={min_x:.2f})")

    # --- 2. Find the Root Node (Trace Backwards) ---
    output_lines.append("Tracing backwards to find root...")
    current_trace_back_id = lowest_x_node_id
    root_node_id = lowest_x_node_id
    visited_backward = {current_trace_back_id} # Prevent cycles in backward trace

    while True:
        incoming = incoming_connections.get(current_trace_back_id, [])
        num_incoming = len(incoming)

        if num_incoming == 0:
            output_lines.append(f"Found root node (no incoming connections): {current_trace_back_id}")
            root_node_id = current_trace_back_id
            break
        elif num_incoming == 1:
            from_node = incoming[0]['from_node']
            if from_node in visited_backward:
                 output_lines.append(f"Warning: Cycle detected during backward trace at node {from_node}. Stopping trace.")
                 # The node *before* the cycle start is the effective root for this logic
                 root_node_id = current_trace_back_id
                 break
            if from_node not in nodes_dict:
                 output_lines.append(f"Warning: Backward trace encountered missing node ID {from_node}. Stopping trace.")
                 root_node_id = current_trace_back_id # Node before the missing one is the effective root
                 break

            # Continue tracing back
            current_trace_back_id = from_node
            root_node_id = current_trace_back_id # Update potential root
            visited_backward.add(current_trace_back_id)
            # output_lines.append(f"... traced back to {current_trace_back_id}") # Optional detailed trace
        else: # num_incoming > 1
            output_lines.append(f"Stopped backward trace at node {current_trace_back_id} (multiple incoming connections - merge point).")
            # The node where we stopped *is* the furthest back we could uniquely trace
            root_node_id = current_trace_back_id
            break

    output_lines.append(f"Starting forward path from identified root: {root_node_id}")
    output_lines.append("\n--- Identified Process Path ---")

    # --- 3. Trace Forward Path ---
    current_node_id = root_node_id
    path_nodes_details = []
    visited_forward = set()
    step_counter = 0
    stop_reason = "Reached end of traceable path."

    while current_node_id is not None:
        if current_node_id not in nodes_dict:
            stop_reason = f"Encountered non-existent node ID {current_node_id}."
            break
        if current_node_id in visited_forward:
            stop_reason = f"Cycle detected. Re-encountered node {current_node_id}."
            # Add the node where the cycle was detected, then stop
            path_nodes_details.append(nodes_dict[current_node_id])
            break

        visited_forward.add(current_node_id)
        node_data = nodes_dict[current_node_id]
        path_nodes_details.append(node_data)
        step_counter += 1

        # Check conditions to continue/stop
        incoming = incoming_connections.get(current_node_id, [])
        outgoing = outgoing_connections.get(current_node_id, [])
        num_incoming = len(incoming)
        num_outgoing = len(outgoing)

        is_root_node = (current_node_id == root_node_id)

        # Stop conditions (applied after adding the current node):
        # 1. Not the root node AND has multiple incoming connections (merge point)
        if not is_root_node and num_incoming > 1:
            stop_reason = f"Stopped at '{node_data.label}' (Node ID: {current_node_id}) - Merge point (multiple inputs)."
            break
        # 2. Has zero or multiple outgoing connections (end of path or branch point)
        if num_outgoing != 1:
            if num_outgoing == 0:
                 stop_reason = f"Stopped at '{node_data.label}' (Node ID: {current_node_id}) - End of path (no outputs)."
            else: # num_outgoing > 1
                 stop_reason = f"Stopped at '{node_data.label}' (Node ID: {current_node_id}) - Branch point (multiple outputs)."
            break

        # If conditions met, continue to the single next node
        current_node_id = outgoing[0]['to_node']

    # --- 4. Format and Print Output ---
    if not path_nodes_details:
         output_lines.append("No forward path could be traced from the root node.")
    else:
        for i, node_data in enumerate(path_nodes_details):
            node_id = node_data.id
            template = node_data.filled_story_template or f"Step for Node {node_id} (No template found)"
             # Simple formatting for the step
            formatted_step = template.strip()
            if formatted_step and not formatted_step.endswith(('.', '?', '!')):
                formatted_step += '.'
            formatted_step = formatted_step[0].upper() + formatted_step[1:] if formatted_step else template

            output_lines.append(f"{i + 1}. {formatted_step}  (Node: {node_id})") # Add Node ID for reference

    output_lines.append(f"\nPath Description Summary: {stop_reason}")

    return "\n".join(output_lines)


def parse_single_path_from_lowest_x_json(json_data: str) -> str:
    """
    Parses the process flow JSON to find a single path based on the
    lowest X-coordinate node, tracing backwards to find its root,
    and then forwards until a branch or merge point.

    Args:
        json_data (str): A JSON string containing the process flow data.

    Returns:
        str: A formatted string describing the single identified process path.
    """
    try:
        data = json.loads(json_data)
    except json.JSONDecodeError as e:
        return f"Error: Invalid JSON provided. {e}"

    # Convert JSON data to FlowSchema
    from barfi.flow.schema.types import build_flow_schema_from_dict
    
    try:
        # Handle both direct schema and nested schemas
        if "editor_schema" in data:
            schema_dict = data["editor_schema"]
        else:
            schema_dict = data
            
        flow_schema = build_flow_schema_from_dict(schema_dict)
        return parse_single_path_from_lowest_x(flow_schema)
    except Exception as e:
        return f"Error: Failed to convert JSON to FlowSchema. {e}"

def parse_all_paths(flow_schema: FlowSchema) -> str:
    """
    Parses the process flow schema to find all distinct paths through the flow,
    starting from the leftmost node(s) and tracing all branches.
    
    Key rules:
    1. Each node with multiple inputs (merge point) starts a new path
    2. Each node with multiple outputs (branch point) ends its path
    3. Paths are traced from roots and merge points

    Args:
        flow_schema (FlowSchema): A FlowSchema object containing the process flow data.

    Returns:
        str: A formatted string describing all identified process paths.
    """
    nodes = flow_schema.nodes
    connections = flow_schema.connections
    viewport = flow_schema.viewport

    if not nodes:
        return "Error: No nodes found in the flow schema."

    # --- 1. Preprocessing ---
    nodes_dict = {}
    # Calculate node positions relative to the viewport
    viewport_x = viewport.x if hasattr(viewport, 'x') else 0
    
    # Track nodes by absolute position for better path separation
    nodes_by_pos_x = []

    for node in nodes:
        node_id = node.id
        if not node_id:
            print(f"Warning: Found node without ID: {node.label}")
            continue
        nodes_dict[node_id] = node
        try:
            # Get absolute X position
            pos_x = float(node.position.x)
            # Store node with its position for sorting
            nodes_by_pos_x.append((node_id, pos_x))
        except (ValueError, TypeError):
            print(f"Warning: Could not parse X position for node {node_id}. Skipping for position sorting.")

    # Sort nodes by X position (left to right)
    nodes_by_pos_x.sort(key=lambda x: x[1])

    # Build incoming/outgoing connection lookups with interface information
    # outgoing: {'node_id': [{'to_node': id, 'from_interface': name, 'to_interface': name}, ...]}
    outgoing_connections = {node_id: [] for node_id in nodes_dict}
    # incoming: {'node_id': [{'from_node': id, 'to_interface': name, 'from_interface': name}, ...]}
    incoming_connections = {node_id: [] for node_id in nodes_dict}

    for conn in connections:
        output_node = conn.outputNode
        input_node = conn.inputNode
        output_interface = conn.outputNodeInterface
        input_interface = conn.inputNodeInterface

        if output_node and input_node and output_interface and output_node in nodes_dict:
            outgoing_connections[output_node].append({
                'to_node': input_node,
                'from_interface': output_interface,
                'to_interface': input_interface,
                'connection_id': conn.id
            })

        if input_node and output_node and input_interface and input_node in nodes_dict:
            incoming_connections[input_node].append({
                'from_node': output_node,
                'to_interface': input_interface,
                'from_interface': output_interface,
                'connection_id': conn.id
            })

    # --- 2. Identify branch points and merge points ---
    branch_points = set()  # Nodes with multiple outputs
    merge_points = set()  # Nodes with multiple inputs
    
    for node_id in nodes_dict:
        if len(outgoing_connections[node_id]) > 1:
            branch_points.add(node_id)
        
        # Check for merge points
        if len(incoming_connections.get(node_id, [])) > 1:
            merge_points.add(node_id)
    
    # --- 3. Find all Root Nodes ---
    root_nodes = []
    # Consider nodes with no inputs as primary roots
    for node_id in nodes_dict:
        if len(incoming_connections[node_id]) == 0:
            root_nodes.append(node_id)
    
    # Sort root nodes by X position for proper ordering of paths
    root_nodes = sorted(root_nodes, key=lambda node_id: 
                        next((pos for nid, pos in nodes_by_pos_x if nid == node_id), float('inf')))

    # --- 4. Add merge points as path starting points ---
    # Merge points also start paths
    path_starting_points = root_nodes.copy()
    for node_id in merge_points:
        if node_id not in path_starting_points:
            path_starting_points.append(node_id)
    
    # Sort by X coordinate for consistent ordering
    path_starting_points = sorted(path_starting_points, key=lambda node_id: 
                                 next((pos for nid, pos in nodes_by_pos_x if nid == node_id), float('inf')))

    # --- 5. Trace Paths (Revised Logic) ---
    junction_nodes = merge_points.union(branch_points)
    complete_paths = []
    path_counter = 1
    nodes_in_linear_paths = set()

    # 5a. Create Junction Paths
    junction_path_map = {}
    for junction_node_id in junction_nodes:
        path_type = "unknown_junction"
        if junction_node_id in merge_points and junction_node_id in branch_points:
             path_type = "merge_and_branch_node"
        elif junction_node_id in merge_points:
             path_type = "merge_node"
        elif junction_node_id in branch_points:
             path_type = "branch_node"

        path_info = {
            "path": [junction_node_id],
            "type": path_type,
            "id": path_counter # Temporary ID
        }
        complete_paths.append(path_info)
        junction_path_map[junction_node_id] = path_info # Map node ID to its path info
        path_counter += 1

    # 5b. Trace Linear Paths from Roots
    active_traces = [] # Store traces: (current_node_id, current_path_nodes, current_connection_info)
    for root_node_id in root_nodes:
        # Skip roots that are also junctions (handled above)
        if root_node_id not in junction_nodes:
            active_traces.append((root_node_id, [root_node_id], []))
            nodes_in_linear_paths.add(root_node_id)

    # 5c. Trace Linear Paths After Junctions
    for junction_node_id in junction_nodes:
        for conn in outgoing_connections.get(junction_node_id, []):
            next_node_id = conn['to_node']
            # If the next node is NOT a junction, start a linear trace from it
            if next_node_id and next_node_id in nodes_dict and next_node_id not in junction_nodes:
                # Check if this node is already part of another linear trace start
                if next_node_id not in nodes_in_linear_paths:
                     active_traces.append((next_node_id, [next_node_id], []))
                     nodes_in_linear_paths.add(next_node_id)
                # Store connection info for linking later
                if junction_node_id not in junction_path_map:
                     print(f"Warning: Junction node {junction_node_id} missing from map.")
                     continue
                if 'post_junction_starts' not in junction_path_map[junction_node_id]:
                    junction_path_map[junction_node_id]['post_junction_starts'] = []
                junction_path_map[junction_node_id]['post_junction_starts'].append(
                    {'next_node_id': next_node_id, 'from_interface': conn['from_interface']}
                )
            # Handle connection if next node IS a junction
            elif next_node_id and next_node_id in junction_nodes:
                 if 'junction_to_junction' not in junction_path_map[junction_node_id]:
                     junction_path_map[junction_node_id]['junction_to_junction'] = []
                 junction_path_map[junction_node_id]['junction_to_junction'].append(
                     {'next_junction_id': next_node_id, 'from_interface': conn['from_interface']}
                 )

    # 5d. Execute Tracing for Linear Paths
    finished_linear_paths = []
    while active_traces:
        current_node_id, current_path_nodes, current_connection_info = active_traces.pop(0)
        path_ended = False

        while not path_ended:
            outgoing = outgoing_connections.get(current_node_id, [])
            if not outgoing:
                # Reached an endpoint
                finished_linear_paths.append({
                    "path": list(current_path_nodes),
                    "connection_info": list(current_connection_info),
                    "type": "linear_endpoint",
                    "ends_at_junction": None, # Mark end reason
                    "id": path_counter # Temporary ID
                })
                path_counter += 1
                path_ended = True
            else:
                # Assume only one outgoing for linear paths by definition
                # (This relies on junctions being handled separately)
                if len(outgoing) > 1:
                     # This should technically not happen if junctions are pre-identified
                     print(f"Warning: Linear path trace encountered unexpected branch at {current_node_id}")
                     # Treat as ending before the branch
                     finished_linear_paths.append({
                         "path": list(current_path_nodes),
                         "connection_info": list(current_connection_info),
                         "type": "linear_to_branch", # Or treat as error?
                         "ends_at_junction": current_node_id, # Which is a branch
                         "id": path_counter
                     })
                     path_counter += 1
                     path_ended = True
                     continue

                next_conn = outgoing[0]
                next_node_id = next_conn['to_node']

                if next_node_id is None or next_node_id not in nodes_dict:
                    print(f"Warning: Linear path trace encountered connection to invalid node from {current_node_id}")
                    finished_linear_paths.append({
                        "path": list(current_path_nodes),
                        "connection_info": list(current_connection_info),
                        "type": "linear_error",
                        "ends_at_junction": None,
                        "id": path_counter
                    })
                    path_counter += 1
                    path_ended = True

                elif next_node_id in junction_nodes:
                    # Reached a junction, end the linear path *before* it
                    finished_linear_paths.append({
                        "path": list(current_path_nodes),
                        "connection_info": list(current_connection_info),
                        "type": "linear_to_junction",
                        "ends_at_junction": next_node_id, # Store which junction it leads to
                        "via_interface": next_conn['from_interface'], # Interface used to connect
                        "id": path_counter
                    })
                    path_counter += 1
                    path_ended = True
                else:
                    # Continue linear path
                    if next_node_id in nodes_in_linear_paths:
                         print(f"Warning: Cycle or overlap detected in linear path involving {next_node_id}. Stopping trace segment.")
                         # End path before the repeated node
                         finished_linear_paths.append({
                            "path": list(current_path_nodes),
                            "connection_info": list(current_connection_info),
                            "type": "linear_cycle",
                            "ends_at_junction": None, # Not a junction end
                            "id": path_counter
                         })
                         path_counter += 1
                         path_ended = True
                         continue

                    nodes_in_linear_paths.add(next_node_id)
                    current_connection_info.append({
                        'from_node': current_node_id,
                        'to_node': next_node_id,
                        'from_interface': next_conn['from_interface'],
                        'to_interface': next_conn['to_interface']
                    })
                    current_path_nodes.append(next_node_id)
                    current_node_id = next_node_id # Advance

    # Combine junction paths and finished linear paths
    complete_paths.extend(finished_linear_paths)

    # --- 6. Sort paths and Re-ID ---
    def get_sort_key(path_info):
        path = path_info["path"]
        if not path:
            return (float('inf'), float('inf'))

        # Use the first node in the path for positioning
        first_node_id = path[0]
        pos_x = float('inf')
        pos_y = float('inf')

        if first_node_id in nodes_dict:
            try:
                pos_x = float(nodes_dict[first_node_id].position.x)
                pos_y = float(nodes_dict[first_node_id].position.y)
            except (ValueError, TypeError, AttributeError):
                pass # Keep inf if position missing

        return (pos_x, pos_y)

    # Assign temporary IDs before sorting
    for i, p in enumerate(complete_paths):
        p['_temp_id'] = i

    # Sort paths using the refined key (X, then Y of the first node)
    complete_paths = sorted(complete_paths, key=get_sort_key)

    # Re-assign final path IDs based on the sorted order
    linear_path_node_map = {} # Map start node ID -> linear path info
    final_path_id_map = {} # Map old temp ID -> new final ID
    for new_id, path_info in enumerate(complete_paths, 1):
        path_info["id"] = new_id
        final_path_id_map[path_info['_temp_id']] = new_id
        # Map linear path starting nodes for easier connection lookup
        if path_info["type"].startswith("linear_") and path_info["path"]:
             linear_path_node_map[path_info["path"][0]] = path_info

    # Update junction path map with final IDs
    for junction_node_id, path_info in junction_path_map.items():
         path_info["id"] = final_path_id_map[path_info['_temp_id']]

    # --- 7. Build Connections and Generate Output ---
    nodes_in_paths = {} # Map node_id -> list of path_ids it belongs to
    for path_info in complete_paths:
        path_id = path_info["id"]
        for node_id in path_info["path"]:
            if node_id not in nodes_in_paths:
                nodes_in_paths[node_id] = []
            if path_id not in nodes_in_paths[node_id]:
                 nodes_in_paths[node_id].append(path_id)

    path_connections = {} # Map path_id -> {"to_paths": [...]} 

    # 7a. Connect Linear Paths to Following Junctions
    for linear_path in finished_linear_paths:
        if linear_path["type"] == "linear_to_junction":
            current_path_id = final_path_id_map[linear_path['_temp_id']]
            next_junction_id = linear_path["ends_at_junction"]
            interface = linear_path.get("via_interface")
            
            if next_junction_id in junction_path_map:
                target_path_id = junction_path_map[next_junction_id]["id"]
                if current_path_id not in path_connections:
                    path_connections[current_path_id] = {"to_paths": []}
                path_connections[current_path_id]["to_paths"].append({
                    "path_id": target_path_id,
                    "via": "linear_to_junction",
                    "interface": interface or ""
                })
            else:
                 print(f"Warning: Target junction {next_junction_id} not found in junction map.")

    # 7b. Connect Junctions to Following Paths (Linear or Junction)
    for junction_node_id, junction_path in junction_path_map.items():
        current_path_id = junction_path["id"]

        # Connect to subsequent linear paths
        if 'post_junction_starts' in junction_path:
            for start_info in junction_path['post_junction_starts']:
                next_node_id = start_info['next_node_id']
                interface = start_info['from_interface']
                # Find the linear path that starts with this node
                if next_node_id in linear_path_node_map:
                    target_path_id = linear_path_node_map[next_node_id]["id"]
                    if current_path_id not in path_connections:
                        path_connections[current_path_id] = {"to_paths": []}
                    path_connections[current_path_id]["to_paths"].append({
                        "path_id": target_path_id,
                        "via": "junction_to_linear",
                        "interface": interface
                    })
                else:
                    print(f"Warning: Linear path starting with {next_node_id} not found.")

        # Connect to subsequent junction paths
        if 'junction_to_junction' in junction_path:
            for j2j_info in junction_path['junction_to_junction']:
                next_junction_id = j2j_info['next_junction_id']
                interface = j2j_info['from_interface']
                if next_junction_id in junction_path_map:
                    target_path_id = junction_path_map[next_junction_id]["id"]
                    if current_path_id not in path_connections:
                         path_connections[current_path_id] = {"to_paths": []}
                    path_connections[current_path_id]["to_paths"].append({
                         "path_id": target_path_id,
                         "via": "junction_to_junction",
                         "interface": interface
                    })
                else:
                     print(f"Warning: Target junction {next_junction_id} not found for j2j connection.")

    # --- 8. Format Output ---
    output_lines = ["--- All Flow Paths ---"]
    
    for path_info in complete_paths:
        path_id = path_info["id"]
        path_type = path_info["type"]
        path = path_info["path"]
        connection_info = path_info.get("connection_info", [])
        root_type = path_info.get("root_type", "unknown")
        
        if not path:  # Skip empty paths
            continue
        
        output_lines.append(f"\n=== Path {path_id} ===")
        
        start_node_id_for_header = path[0]
        start_node_label_for_header = nodes_dict[start_node_id_for_header].label if start_node_id_for_header in nodes_dict else "Unknown"

        if root_type == "merge":
            output_lines.append(f"Type: {path_type} (starts at merge point {start_node_label_for_header})")
        elif root_type == "branch_output":
             # Get the actual branch node label (which is path[0])
            branch_node_label = nodes_dict[path[0]].label if path[0] in nodes_dict else "Unknown Branch Node"
            output_lines.append(f"Type: {path_type} (continues from branch {branch_node_label})")
        else: # Root node start
            output_lines.append(f"Type: {path_type}")
        
        # Determine which nodes to iterate over for steps
        nodes_to_enumerate = path
        step_offset = 0
        if root_type == "branch_output" and len(path) > 1:
             nodes_to_enumerate = path[1:] # Skip the branch node itself in the steps
             step_offset = 1 # We skipped the first node

        # Format nodes in this path segment
        for i, node_id in enumerate(nodes_to_enumerate):
            node_data = nodes_dict[node_id]
            template = node_data.filled_story_template or f"Step using {node_data.name} (Node: {node_id})"

            # Get connection information for this node
            input_info = ""
            # Determine the actual index in the full path for connection checking
            current_full_path_index = i + step_offset

            if current_full_path_index > 0:
                # Get the ID of the node providing input in this step
                # This is the node *before* the current one in the *full* path
                input_source_node_id = path[current_full_path_index - 1]

                # Get all incoming connections for this node
                node_incoming = incoming_connections.get(node_id, [])
                
                # Collect all inputs to show in the step
                input_details = []
                
                # Look through connection_info to find connections in the current path
                for conn in connection_info:
                    if conn.get('to_node') == node_id:
                        from_node_id = conn.get('from_node')
                        input_interface = conn.get('to_interface', '')
                        output_interface = conn.get('from_interface', '')
                        # Get the source node label/name for better context
                        from_node_label = nodes_dict[from_node_id].label if from_node_id in nodes_dict else "Unknown"
                        
                        # This is within the current path, so don't add path indicator for inputs from the same path
                        if input_interface and output_interface:
                            input_details.append(f'"{output_interface}" as "{input_interface}" from "{from_node_label}"')
                
                # Also add inputs from other connections outside the current path
                for conn in node_incoming:
                    from_node_id = conn.get('from_node')
                    # Skip connections already included in the path
                    already_included = any(c.get('from_node') == from_node_id and c.get('to_node') == node_id 
                                          for c in connection_info)
                    if not already_included:
                        input_interface = conn.get('to_interface', '')
                        output_interface = conn.get('from_interface', '')
                        from_node_label = nodes_dict[from_node_id].label if from_node_id in nodes_dict else "Unknown"
                        
                        # Find which paths contain the source node to identify cross-path connections
                        from_node_paths = []
                        # Use the nodes_in_paths map (which uses final path IDs)
                        if from_node_id in nodes_in_paths:
                            from_node_paths = nodes_in_paths[from_node_id]
                        
                        path_indicator = ""
                        # Only show path if it's different from the current path
                        # And filter out the current path if the source is also in it (e.g., cycles? unlikely with this model)
                        relevant_source_paths = [p for p in from_node_paths if p != path_id]
                        
                        if relevant_source_paths:
                            paths_str = ", ".join([f"Path {p}" for p in sorted(relevant_source_paths)])
                            path_indicator = f" (from {paths_str})"
                        
                        if input_interface and output_interface:
                            input_details.append(f'"{output_interface}" as "{input_interface}" from "{from_node_label}"{path_indicator}')
                
                # Format the input information
                if input_details:
                    if len(input_details) == 1:
                        input_info = f'Using {input_details[0]}: '
                    elif len(input_details) == 2:
                        input_info = f'Using {input_details[0]} and {input_details[1]}: '
                    else:
                        # For more than 2 inputs, format with commas and final "and"
                        inputs_formatted = ", ".join(input_details[:-1]) + f", and {input_details[-1]}"
                        input_info = f'Using {inputs_formatted}: '
            
            # Add node label and connection info
            formatted_step = template.strip()
            if formatted_step and not formatted_step.endswith(('.', '?', '!')):
                formatted_step += '.'
            formatted_step = formatted_step[0].upper() + formatted_step[1:] if formatted_step else template
            # Adjust step number based on the offset
            step_number = i + 1 + step_offset
            full_step = f"{step_number}. {input_info}{formatted_step} ({node_data.label})"
            output_lines.append(full_step)
        
        # Add connections to other paths
        if path_id in path_connections:
            to_paths = path_connections[path_id]["to_paths"]
            if to_paths:
                output_lines.append("   Continues in:")
                for conn in to_paths:
                    # Simplify connection descriptions
                    output_lines.append(f"   - Path {conn['path_id']} (via {conn['interface']} interface)")
                    # if conn["via"] == "merge":
                    #     output_lines.append(f"   - Path {conn['path_id']} (via {conn['interface']} interface to merge point)")
                    # elif conn["via"] == "branch":
                    #     output_lines.append(f"   - Path {conn['path_id']} (via branch output {conn['interface']})")
                    # elif conn["via"] == "branch_to_middle":
                    #     node_name = nodes_dict[conn["node"]].name if conn["node"] in nodes_dict else "unknown"
                    #     output_lines.append(f"   - Path {conn['path_id']} (branch connects to {node_name} via {conn['interface']})")
    
    # --- Summary Section ---
    # (Remove old summary generation logic)
    # Summary - based on path types and connections
    output_lines.append(f"\nSummary: Identified {len(complete_paths)} distinct paths/segments")
    
    # Identify Root Paths (linear starting from a true root)
    root_linear_paths = []
    for path_info in complete_paths:
        path = path_info.get("path", [])
        if not path: continue
        start_node_id = path[0]
        # Check if it's a linear path and starts with a root node
        if path_info["type"].startswith("linear") and start_node_id in root_nodes:
            node = nodes_dict.get(start_node_id)
            if node: root_linear_paths.append((f"{node.name} ({node.label})", path_info["id"]))
    
    if root_linear_paths:
        output_lines.append("Root Paths (Linear):")
        for label, pid in sorted(root_linear_paths):
            output_lines.append(f"- {label}: Starts Path {pid}")
            
    # List Junction Paths
    junction_paths_info = []
    for jid, jpath in junction_path_map.items():
        node = nodes_dict.get(jid)
        if node: junction_paths_info.append((f"{node.name} ({node.label}) [{jpath['type']}]", jpath["id"]))
        
    if junction_paths_info:
        output_lines.append("Junction Points (Single Node Paths):")
        for label, pid in sorted(junction_paths_info):
            output_lines.append(f"- {label}: Path {pid}")
            
    # List Post-Junction Linear Paths
    post_junction_linear = []
    for node_id, linear_path in linear_path_node_map.items():
        # Check if this linear path starts *after* a junction
        # (We know this because it's in linear_path_node_map but not a root node)
        if node_id not in root_nodes:
             node = nodes_dict.get(node_id)
             if node: post_junction_linear.append((f"{node.name} ({node.label})", linear_path["id"]))
             
    if post_junction_linear:
        output_lines.append("Linear Segments after Junctions:")
        for label, pid in sorted(post_junction_linear):
            output_lines.append(f"- Starts with {label}: Path {pid}")

    # Generate Flow Overview based on recalculated levels (Keep existing logic for now)

    # Final join
    return "\n".join(output_lines)

def find_root(node_id: str, incoming_connections: Dict, nodes_dict: Dict) -> Optional[str]:
    """
    Helper function to trace backward from a node to find a root node.
    
    Args:
        node_id: Starting node ID to trace back from
        incoming_connections: Dictionary of incoming connections
        nodes_dict: Dictionary of all nodes
        
    Returns:
        Root node ID or None if a cycle is detected
    """
    visited = set()
    current_id = node_id
    
    while current_id and current_id not in visited:
        incoming = incoming_connections.get(current_id, [])
        
        # If no incoming connections, this is a root
        if not incoming:
            return current_id
            
        # If multiple incoming, this is as far back as we can go uniquely
        if len(incoming) > 1:
            return current_id
            
        # Mark as visited to detect cycles
        visited.add(current_id)
        
        # Move to the next node back
        current_id = incoming[0]['from_node'] if incoming else None
        
        # Check if next node exists
        if current_id and current_id not in nodes_dict:
            return None
    
    # If we get here with a current_id, we found a cycle
    # Return the current node as the effective "root" for this path
    return current_id

def parse_all_paths_json(json_data: str) -> str:
    """
    Parses the process flow JSON to find all paths through the flow.
    
    Args:
        json_data (str): A JSON string containing the process flow data.
        
    Returns:
        str: A formatted string describing all identified process paths.
    """
    try:
        data = json.loads(json_data)
    except json.JSONDecodeError as e:
        return f"Error: Invalid JSON provided. {e}"
        
    # Convert JSON data to FlowSchema
    from barfi.flow.schema.types import build_flow_schema_from_dict
    
    try:
        # Handle both direct schema and nested schemas
        if "editor_schema" in data:
            schema_dict = data["editor_schema"]
        else:
            schema_dict = data
            
        flow_schema = build_flow_schema_from_dict(schema_dict)
        return parse_all_paths(flow_schema)
    except Exception as e:
        return f"Error: Failed to convert JSON to FlowSchema. {e}"
