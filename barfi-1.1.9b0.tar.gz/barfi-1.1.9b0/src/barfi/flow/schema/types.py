import gzip
import json
import os
from typing import Dict, List, Union, Optional
from dataclasses import dataclass, field, asdict
from barfi.config import SCHEMA_VERSION
from barfi.flow.block import Block

NodeOptionValue = Union[int, float, str, None, bool]
NodeInterfaceValue = Union[int, float, str, None, bool]

@dataclass
class FlowNodePosition:
    """Represents the position of a node in the flow editor.

    Attributes:
        x (float): X-coordinate position of the node
        y (float): Y-coordinate position of the node
    """
    x: float
    y: float

@dataclass
class FlowNodeMeasured:
    """Represents the dimensions of a node in the flow editor.

    Attributes:
        width (int): Width of the node in pixels
        height (int): Height of the node in pixels
    """
    width: int
    height: int

@dataclass
class FlowNodeInterface:
    name: str
    itype: str

@dataclass
class FlowNodeOption:
    name: str
    value: NodeOptionValue
    hint: Optional[str] = None

@dataclass
class FlowNode:
    """Represents a node in the flow editor with its complete configuration.

    Attributes:
        id (str): Unique identifier for the node
        type (str): Type of the node, this is the name of the block derived from the base blocks
        name (str): Display name of the node, a label for identifying the node by a string
        inputs (List[FlowNodeInterface]): List of input interfaces with name and valueType
        outputs (List[FlowNodeInterface]): List of output interfaces with name and valueType
        options (List[FlowNodeOption]): List of node options with name and value
        position (FlowNodePosition): Position of the node in the editor
        measured (FlowNodeMeasured): Dimensions of the node
        code (str): Dedicated field to store the Python editor content for custom blocks
        description (str): Description text content for descBlocks
        block_display_type (Optional[str]): Type of block to use for display (baseBlock, customBlock, descBlock)
        header_color (Optional[str]): Optional color for the node header
        flipped (bool): Whether the descBlock is showing the front or back side
        note (Optional[str]): Additional notes for the node
        story_template (Optional[str]): Template text for dynamic content based on block options
        filled_story_template (Optional[str]): Filled template with actual values, only used when saving
        ico (Optional[str]): Material UI icon name to be displayed in the node header
    """
    id: str
    type: str
    name: str
    label: str
    inputs: List[FlowNodeInterface]
    outputs: List[FlowNodeInterface]
    options: List[FlowNodeOption]
    position: FlowNodePosition
    measured: FlowNodeMeasured
    code: str = ""  # Added dedicated field for Python editor content.
    description: str = ""  # Added dedicated field for description text content.
    block_display_type: Optional[str] = "baseBlock"  # Type of block to use for display
    header_color: Optional[str] = None  # Added field for header color
    flipped: bool = False  # Added field to track flip state for descBlocks
    note: Optional[str] = None  # Added field for notes
    story_template: Optional[str] = None  # Added field for story templates
    filled_story_template: Optional[str] = None  # Filled template with actual values, only used when saving
    ico: Optional[str] = None  # Added field for Material UI icon
    
    def export(self) -> dict:
        """Export the node to a dictionary.
        
        Returns:
            dict: The node as a dictionary with snake_case fields only.
        """
        # Just return the standard dataclass dictionary - no need to add headerColor
        return asdict(self)

@dataclass
class FlowConnection:
    """Represents a connection between two nodes in the flow editor.

    Attributes:
        id (str): Unique identifier for the connection
        outputNode (str): ID of the node where the connection starts
        outputNodeInterface (str): Name of the output interface on the source node
        inputNode (str): ID of the node where the connection ends
        inputNodeInterface (str): Name of the input interface on the target node
    """
    id: str
    outputNode: str
    outputNodeInterface: str
    inputNode: str
    inputNodeInterface: str

@dataclass
class FlowViewport:
    """Represents the current view state of the flow editor.

    Attributes:
        x (float): X-coordinate of the viewport position
        y (float): Y-coordinate of the viewport position
        zoom (float): Current zoom level of the viewport
    """
    x: float
    y: float
    zoom: float

@dataclass
class FlowSchema:
    """Represents the complete schema of a flow diagram.

    Attributes:
        version (str): Schema version identifier
        nodes (List[FlowNode]): List of all nodes in the flow
        connections (List[FlowConnection]): List of all connections between nodes
        viewport (FlowViewport): Current state of the editor viewport
    """
    version: str
    nodes: List[FlowNode]
    connections: List[FlowConnection]
    viewport: FlowViewport

    _block_map: Dict[str, Block] = field(
        init=False,
        default_factory=dict,
        repr=False,
        compare=False,
        metadata={"export": False},
    )

    def block(
        self, node: FlowNode = None, node_id: str = None, node_label: str = None
    ) -> Block:
        """
        Creates or retrieves a Block instance from a FlowNode or node identifiers.

        Args:
            node (FlowNode, optional): FlowNode instance to create block from. Defaults to None.
            node_id (str, optional): Unique identifier for the node. Defaults to None.
            node_label (str, optional): Display label for the node. Defaults to None.

        Returns:
            Block: A Block instance representing the node in the flow.

        Example:
            >>> block = flow_schema.block(node_label="Result-1")
        """
        if node:
            node_id = node.id
            node_label = node.label

        if node_label:
            node_id = next((n.id for n in self.nodes if n.label == node_label), None)

        if node_id is None or node_id not in self._block_map:
            raise ValueError(
                "Could not find block: no valid node ID, node, or label was provided"
            )

        return self._block_map[node_id]

    def export(self) -> dict:
        """
        Convert the dataclass to a dictionary, excluding fields marked with metadata `export=False`.
        """
        result = {
            key: value
            for key, value in asdict(self).items()
            if self.__dataclass_fields__[key].metadata.get("export", True)
        }
        
        # Use custom export for nodes to ensure UI compatibility
        result["nodes"] = [node.export() for node in self.nodes]
        
        return result

def build_flow_schema_from_dict(schema_dict: dict) -> FlowSchema:
    # TODO: Move this to a classmethod of FlowSchema.
    return FlowSchema(
        version=schema_dict.get("version", SCHEMA_VERSION),
        nodes=[
            FlowNode(
                **{
                    **{k: v for k, v in node.items() if k not in ['headerColor']},  # Filter out headerColor
                    "inputs": [FlowNodeInterface(**input) for input in node["inputs"]],
                    "outputs": [FlowNodeInterface(**output) for output in node["outputs"]],
                    "options": [FlowNodeOption(**option) for option in node["options"]],
                    "position": FlowNodePosition(**node["position"]),
                    "measured": FlowNodeMeasured(**node["measured"]),
                    "code": node.get("code", ""),  # Dedicated field for Python editor content
                    "description": node.get("description", ""),  # Dedicated field for description text
                    "block_display_type": node.get("block_display_type", "baseBlock"),  # Default to baseBlock if not specified
                    # Handle both header_color and headerColor for backward compatibility, 
                    # but convert everything to header_color
                    "header_color": node.get("header_color") if "header_color" in node else node.get("headerColor"),
                    # Add flipped state for descBlocks
                    "flipped": node.get("flipped", False),
                    # Add note field if it exists
                    "note": node.get("note"),
                    # Add story_template field if it exists
                    "story_template": node.get("story_template"),
                    # Add filled_story_template field if it exists
                    "filled_story_template": node.get("filled_story_template"),
                    # Add ico field if it exists
                    "ico": node.get("ico"),
                }
            )
            for node in schema_dict.get("nodes", [])
        ],
        connections=[FlowConnection(**conn) for conn in schema_dict.get("connections", [])],
        viewport=FlowViewport(**schema_dict.get("viewport", {})),
    )
